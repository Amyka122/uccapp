package com.groupassess.uccitdept


import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity

import android.os.Bundle
import android.text.method.LinkMovementMethod
import android.view.View
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setContentView(R.layout.admissions)
        setContentView(R.layout.staffdirectory)
        setContentView(R.layout.timetable_screen)


        fun setupHyperlink() {
            val linkTextView = findViewById<TextView>(R.id.link)
            linkTextView.movementMethod = LinkMovementMethod.getInstance()
            linkTextView.setLinkTextColor(Color.BLUE)
        }

        fun viewstaff(view: View?) {
            val Intent = Intent(this, staffdirectory::class.java)
            startActivity(intent)
        }
            public void viewadmissions(View view) {
                val Intent = Intent(this, admissions.class)
                startActivity(intent)



        }
    }
}