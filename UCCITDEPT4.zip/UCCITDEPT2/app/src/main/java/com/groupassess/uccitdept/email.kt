package com.groupassess.uccitdept

import com.google.android.material.floatingactionbutton.FloatingActionButton
import android.view.View
import android.content.Intent

class email {
    private val fab: FloatingActionButton? = null
    fun onClick(view: View?) {
        val Email = Intent(Intent.ACTION_SEND)
        Email.type = "text/email"
        Email.putExtra(Intent.EXTRA_EMAIL, arrayOf("developeremail@gmail.com")) //developer 's email
        Email.putExtra(
            Intent.EXTRA_SUBJECT,
            "Add your Subject"
        ) // Email 's Subject
        Email.putExtra(Intent.EXTRA_TEXT, "Dear Developer Name," + "") //Email 's Greeting text
        startActivity(Intent.createChooser(Email, "Send Feedback:"))
    }
}