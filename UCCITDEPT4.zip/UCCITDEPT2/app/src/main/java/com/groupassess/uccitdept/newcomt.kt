package com.groupassess.uccitdept

import android.view.View
import android.content.Intent

class newcomt {
    fun viewstaff(view: View?) {
        val Intent = Intent(this, staffdirectory::class.java)
        startActivity(intent)
    }
}