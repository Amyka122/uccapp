package com.groupassess.uccitdept

import android.app.Activity
import android.view.View
import android.widget.TextView
import android.widget.Button
import android.widget.EditText
import android.os.Bundle
import android.view.Window
import android.view.WindowManager
import com.groupassess.uccitdept.R
import android.graphics.Typeface
import android.view.Menu
import java.util.*

class TimetableScreen : Activity(), View.OnClickListener {
    var daynumber = 0
    var todaynumber = 0
    var day: TextView? = null
    var c1: TextView? = null
    var c2: TextView? = null
    var c3: TextView? = null
    var c4: TextView? = null
    var c5: TextView? = null
    var c6: TextView? = null
    var c7: TextView? = null
    var c8: TextView? = null
    var c9: TextView? = null
    var c10: TextView? = null
    var cn1: TextView? = null
    var cn2: TextView? = null
    var cn3: TextView? = null
    var cn4: TextView? = null
    var cn5: TextView? = null
    var cn6: TextView? = null
    var cn7: TextView? = null
    var cn8: TextView? = null
    var cn9: TextView? = null
    var cn10: TextView? = null
    var lpt1: TextView? = null
    var lpt2: TextView? = null
    var lpt3: TextView? = null
    var lpt4: TextView? = null
    var lpt5: TextView? = null
    var lpt6: TextView? = null
    var lpt7: TextView? = null
    var lpt8: TextView? = null
    var lpt9: TextView? = null
    var lpt10: TextView? = null
    var taptext: TextView? = null
    var bEdit: Button? = null
    var bEnter: Button? = null
    var bDone: Button? = null
    var textbox: EditText? = null
    var mc = arrayOfNulls<String>(10)
    var mcn = arrayOfNulls<String>(10)
    var ml = arrayOfNulls<String>(10)
    var tc = arrayOfNulls<String>(10)
    var tcn = arrayOfNulls<String>(10)
    var tl = arrayOfNulls<String>(10)
    var wc = arrayOfNulls<String>(10)
    var wcn = arrayOfNulls<String>(10)
    var wl = arrayOfNulls<String>(10)
    var thc = arrayOfNulls<String>(10)
    var thcn = arrayOfNulls<String>(10)
    var thl = arrayOfNulls<String>(10)
    var fc = arrayOfNulls<String>(10)
    var fcn = arrayOfNulls<String>(10)
    var fl = arrayOfNulls<String>(10)
    var sc = arrayOfNulls<String>(10)
    var scn = arrayOfNulls<String>(10)
    var sl = arrayOfNulls<String>(10)
    var suc = arrayOfNulls<String>(10)
    var sucn = arrayOfNulls<String>(10)
    var sul = arrayOfNulls<String>(10)
    var ids = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // full screen
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        setContentView(R.layout.timetable_screen)
        val bNext = findViewById<View>(R.id.bNext) as Button
        val bPrevious = findViewById<View>(R.id.bPrevious) as Button
        var v: View
        v = findViewById(R.id.bToday)
        val bToday = v as Button
        v.setVisibility(View.INVISIBLE)
        v = findViewById(R.id.bEdit)
        bEdit = v as Button
        v = findViewById(R.id.bDone)
        bDone = v as Button
        v.setVisibility(View.INVISIBLE)
        v = findViewById(R.id.bEnter)
        bEnter = v as Button
        v.setVisibility(View.INVISIBLE)
        val TopBar = findViewById<View>(R.id.TopBar) as Button
        val barfont = Typeface.createFromAsset(assets, "ARMTB.ttf")
        TopBar.typeface = barfont
        v = findViewById(R.id.taptext)
        taptext = v as TextView
        v.setVisibility(View.INVISIBLE)
        v = findViewById(R.id.textbox)
        textbox = v as EditText
        v.setVisibility(View.INVISIBLE)
        ids = 0
        day = findViewById<View>(R.id.day) as TextView
        c1 = findViewById<View>(R.id.c1) as TextView
        c2 = findViewById<View>(R.id.c2) as TextView
        c3 = findViewById<View>(R.id.c3) as TextView
        c4 = findViewById<View>(R.id.c4) as TextView
        c5 = findViewById<View>(R.id.c5) as TextView
        c6 = findViewById<View>(R.id.c6) as TextView
        c7 = findViewById<View>(R.id.c7) as TextView
        c8 = findViewById<View>(R.id.c8) as TextView
        c9 = findViewById<View>(R.id.c9) as TextView
        c10 = findViewById<View>(R.id.c10) as TextView
        cn1 = findViewById<View>(R.id.cn1) as TextView
        cn2 = findViewById<View>(R.id.cn2) as TextView
        cn3 = findViewById<View>(R.id.cn3) as TextView
        cn4 = findViewById<View>(R.id.cn4) as TextView
        cn5 = findViewById<View>(R.id.cn5) as TextView
        cn6 = findViewById<View>(R.id.cn6) as TextView
        cn7 = findViewById<View>(R.id.cn7) as TextView
        cn8 = findViewById<View>(R.id.cn8) as TextView
        cn9 = findViewById<View>(R.id.cn9) as TextView
        cn10 = findViewById<View>(R.id.cn10) as TextView
        lpt1 = findViewById<View>(R.id.lpt1) as TextView
        lpt2 = findViewById<View>(R.id.lpt2) as TextView
        lpt3 = findViewById<View>(R.id.lpt3) as TextView
        lpt4 = findViewById<View>(R.id.lpt4) as TextView
        lpt5 = findViewById<View>(R.id.lpt5) as TextView
        lpt6 = findViewById<View>(R.id.lpt6) as TextView
        lpt7 = findViewById<View>(R.id.lpt7) as TextView
        lpt8 = findViewById<View>(R.id.lpt8) as TextView
        lpt9 = findViewById<View>(R.id.lpt9) as TextView
        lpt10 = findViewById<View>(R.id.lpt10) as TextView
        val calendar = Calendar.getInstance()
        daynumber = calendar[Calendar.DAY_OF_WEEK]
        todaynumber = daynumber
        // If current day is Sunday, day=1. Saturday, day=7.
        setValues()
        bEdit!!.setOnClickListener { v -> // TODO Auto-generated method stub
            var v = v
            v = findViewById(R.id.bEdit)
            v.visibility = View.INVISIBLE
            v = findViewById(R.id.taptext)
            v.visibility = View.VISIBLE
        }
        bNext.setOnClickListener { // TODO Auto-generated method stub
            val b = findViewById<View>(R.id.bToday)
            if (b.visibility == View.INVISIBLE) b.visibility = View.VISIBLE
            setAllNull()
            if (daynumber != 7) daynumber++ else daynumber = 1
            if (daynumber == todaynumber) b.visibility = View.INVISIBLE
            setValues()
        }
        bPrevious.setOnClickListener { // TODO Auto-generated method stub
            val b = findViewById<View>(R.id.bToday)
            if (b.visibility == View.INVISIBLE) b.visibility = View.VISIBLE
            setAllNull()
            if (daynumber != 1) daynumber-- else daynumber = 7
            if (daynumber == todaynumber) b.visibility = View.INVISIBLE
            setValues()
        }
        bToday.setOnClickListener { // TODO Auto-generated method stub
            daynumber = todaynumber
            val b = findViewById<View>(R.id.bToday)
            b.visibility = View.INVISIBLE
            setAllNull()
            setValues()
        }
    }

    override fun onClick(v: View) {
        // TODO Auto-generated method stub
    }

    fun setAllNull() {
        c1!!.text = "-"
        c2!!.text = "-"
        c3!!.text = "-"
        c4!!.text = "-"
        c5!!.text = "-"
        c6!!.text = "-"
        c7!!.text = "-"
        c8!!.text = "-"
        c9!!.text = "-"
        c10!!.text = "-"
        cn1!!.text = "-"
        cn2!!.text = "-"
        cn3!!.text = "-"
        cn4!!.text = "-"
        cn5!!.text = "-"
        cn6!!.text = "-"
        cn7!!.text = "-"
        cn8!!.text = "-"
        cn9!!.text = "-"
        cn10!!.text = "-"
        lpt1!!.text = "-"
        lpt2!!.text = "-"
        lpt3!!.text = "-"
        lpt4!!.text = "-"
        lpt5!!.text = "-"
        lpt6!!.text = "-"
        lpt7!!.text = "-"
        lpt8!!.text = "-"
        lpt9!!.text = "-"
        lpt10!!.text = "-"
    }

    fun setValues() {
        when (daynumber) {
            Calendar.SUNDAY -> day!!.text = "Take lite, It's Sunday"
            Calendar.MONDAY -> {
                day!!.text = "Monday"
                c2!!.text = "EG"
                c3!!.text = "EG"
                c4!!.text = "Math 2"
                c5!!.text = "Thermo"
                c8!!.text = "Comp"
                c9!!.text = "P&S"
                cn2!!.text = "CC"
                cn3!!.text = "CC"
                cn4!!.text = "LT2"
                cn5!!.text = "LT3"
                cn8!!.text = "LT2"
                cn9!!.text = "LT2"
                lpt2!!.text = "P"
                lpt3!!.text = "P"
                lpt4!!.text = "L"
                lpt5!!.text = "L"
                lpt8!!.text = "L"
                lpt9!!.text = "L"
            }
            Calendar.TUESDAY -> {
                day!!.text = "Tuesday"
                c1!!.text = "Thermo"
                c4!!.text = "ES"
                c9!!.text = "EG"
                c10!!.text = "Comp"
                cn1!!.text = "A507"
                cn4!!.text = "LT3"
                cn9!!.text = "LT2"
                cn10!!.text = "CC"
                lpt1!!.text = "T"
                lpt4!!.text = "L"
                lpt9!!.text = "L"
                lpt10!!.text = "P"
            }
            Calendar.WEDNESDAY -> {
                day!!.text = "Wednesday"
                c1!!.text = "Math 2"
                c2!!.text = "Chem lab"
                c3!!.text = "Chem lab"
                c4!!.text = "Math 2"
                c5!!.text = "Thermo"
                c8!!.text = "Comp"
                c9!!.text = "P&S"
                cn1!!.text = "C301"
                cn2!!.text = "Chem lab"
                cn3!!.text = "Chem lab"
                cn4!!.text = "LT2"
                cn5!!.text = "LT3"
                cn8!!.text = "LT2"
                cn9!!.text = "LT2"
                lpt1!!.text = "T"
                lpt2!!.text = "P"
                lpt3!!.text = "P"
                lpt4!!.text = "L"
                lpt5!!.text = "L"
                lpt8!!.text = "L"
                lpt9!!.text = "L"
            }
            Calendar.THURSDAY -> {
                day!!.text = "Thursday"
                c4!!.text = "ES"
                c9!!.text = "EG"
                cn4!!.text = "LT3"
                cn9!!.text = "A507"
                lpt4!!.text = "L"
                lpt9!!.text = "T"
            }
            Calendar.FRIDAY -> {
                day!!.text = "Friday"
                c1!!.text = "P&S"
                c4!!.text = "Math 2"
                c5!!.text = "Thermo"
                c8!!.text = "Comp"
                c9!!.text = "P&S"
                cn1!!.text = "LT1"
                cn4!!.text = "LT2"
                cn5!!.text = "LT3"
                cn8!!.text = "LT2"
                cn9!!.text = "LT2"
                lpt1!!.text = "T"
                lpt4!!.text = "L"
                lpt5!!.text = "L"
                lpt8!!.text = "L"
                lpt9!!.text = "L"
            }
            Calendar.SATURDAY -> {
                day!!.text = "Saturday"
                c1!!.text = "ES"
                c4!!.text = "ES"
                cn1!!.text = "LT3"
                cn4!!.text = "LT3"
                lpt1!!.text = "T"
                lpt4!!.text = "L"
            }
        }
    }

    override fun onPause() {
        // TODO Auto-generated method stub
        super.onPause()
        finish()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.timetable_screen, menu)
        return true
    }
}